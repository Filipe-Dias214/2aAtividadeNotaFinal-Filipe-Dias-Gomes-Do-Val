<?php include 'database.php'; ?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Lista de Tarefas</title>
    <style>
        /* Reset básico */
        * {
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #121212;
            color: #e0e0e0;
            padding: 20px;
            margin: 0;
        }

        h2 {
            color: #e74c3c;
            border-bottom: 2px solid #e74c3c;
            padding-bottom: 6px;
            margin-bottom: 20px;
            font-weight: 600;
        }

        form {
            background: #1f1f1f;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(231, 76, 60, 0.5);
            margin-bottom: 30px;
        }

        input[type="text"],
        input[type="date"] {
            background: #2c2c2c;
            border: 1px solid #444;
            border-radius: 6px;
            padding: 10px;
            width: 220px;
            color: #eee;
            font-size: 14px;
            transition: border-color 0.3s ease;
        }

        input[type="text"]:focus,
        input[type="date"]:focus {
            border-color: #e74c3c;
            outline: none;
            background: #3a3a3a;
        }

        button {
            background-color: #e74c3c;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 600;
            font-size: 14px;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #c0392b;
        }

        ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        li {
            background: #1f1f1f;
            margin-bottom: 12px;
            padding: 12px 16px;
            border-radius: 8px;
            box-shadow: 0 1px 4px rgba(0,0,0,0.7);
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: #ddd;
            font-size: 15px;
        }

        li s {
            color: #777;
        }

        a {
            margin-left: 12px;
            text-decoration: none;
            color: #e74c3c;
            font-weight: 600;
            transition: color 0.3s ease;
        }

        a:hover {
            color: #ff6347; /* Tom de vermelho mais claro */
            text-decoration: underline;
        }
    </style>
</head>
<body>

    <h2>Adicionar Nova Tarefa</h2>
    <form action="add_tarefa.php" method="POST">
        <input type="text" name="Tarefa" placeholder="Tarefa" required><br><br>
        <input type="date" name="vencimento" required><br><br>
        <button type="submit">Adicionar Tarefa</button>
    </form>

    <h2>Tarefas Não Concluídas</h2>
    <ul>
        <?php
        $tarefas = $db->query("SELECT * FROM tarefas WHERE concluida = 0 ORDER BY vencimento ASC");
        foreach ($tarefas as $tarefa) {
            echo "<li>{$tarefa['descricao']} - {$tarefa['vencimento']}
                <span>
                <a href='update_tarefa.php?id={$tarefa['id']}'>Concluir</a> | 
                <a href='delete_tarefa.php?id={$tarefa['id']}'>Excluir</a>
                </span>
            </li>";
        }
        ?>
    </ul>

    <h2>Tarefas Concluídas</h2>
    <ul>
        <?php
        $tarefas = $db->query("SELECT * FROM tarefas WHERE concluida = 1 ORDER BY vencimento ASC");
        foreach ($tarefas as $tarefa) {
            echo "<li><s>{$tarefa['descricao']} - {$tarefa['vencimento']}</s> 
                <a href='delete_tarefa.php?id={$tarefa['id']}'>Excluir</a></li>";
        }
        ?>
    </ul>

</body>
</html>
