<?php
include 'database.php';

if (isset($_POST['Tarefa']) && isset($_POST['vencimento'])) {
    $descricao = trim($_POST['Tarefa']);
    $vencimento = $_POST['vencimento'];

    // Inserir a tarefa no banco, marcando como não concluída (0)
    $stmt = $db->prepare("INSERT INTO tarefas (descricao, vencimento, concluida) VALUES (?, ?, 0)");
    $stmt->execute([$descricao, $vencimento]);

    // Redirecionar para a página principal sem output antes
    header('Location: index.php');
    exit;
} else {
    // Dados não enviados, redirecionar para o formulário
    header('Location: index.php');
    exit;
}
