<?php
// Cria a conexão com o banco de dados SQLite
$db = new PDO('sqlite:tarefas.db');

// Cria a tabela se não existir
$db->exec("CREATE TABLE IF NOT EXISTS tarefas (
    id INTEGER PRIMARY KEY,
    descricao TEXT,
    vencimento DATE,
    concluida INTEGER DEFAULT 0
)");
?>
