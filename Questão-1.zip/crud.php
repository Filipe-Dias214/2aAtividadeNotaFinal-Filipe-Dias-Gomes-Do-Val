<?php
try {
  $pdo = new PDO('sqlite:database.db');
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  // Criação da tabela livros com id, titulo, autor e ano
  $sql = "CREATE TABLE IF NOT EXISTS livros (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    titulo TEXT NOT NULL,
    autor TEXT NOT NULL,
    ano INTEGER NOT NULL
  )";
  $pdo->exec($sql);

  $action = $_GET['action'] ?? '';

  if ($action === 'create') {
    $titulo = $_POST['titulo'] ?? '';
    $autor = $_POST['autor'] ?? '';
    $ano = $_POST['ano'] ?? '';

    // Log para debug
    file_put_contents('debug.txt', "CREATE recebido: titulo=$titulo, autor=$autor, ano=$ano\n", FILE_APPEND);

    if ($titulo && $autor && $ano) {
      $stmt = $pdo->prepare("INSERT INTO livros (titulo, autor, ano) VALUES (:titulo, :autor, :ano)");
      $stmt->bindParam(':titulo', $titulo);
      $stmt->bindParam(':autor', $autor);
      $stmt->bindParam(':ano', $ano, PDO::PARAM_INT);
      echo $stmt->execute() ? "Livro cadastrado com sucesso!" : "Erro ao cadastrar livro!";
    } else {
      echo "Título, Autor e Ano são obrigatórios!";
    }
  }
  elseif ($action === 'read') {
    $stmt = $pdo->query("SELECT * FROM livros");
    $livros = $stmt->fetchAll(PDO::FETCH_ASSOC);
    header('Content-Type: application/json');
    echo json_encode($livros);
  }
  elseif ($action === 'update') {
    $id = $_POST['id'] ?? '';
    $titulo = $_POST['titulo'] ?? '';
    $autor = $_POST['autor'] ?? '';
    $ano = $_POST['ano'] ?? '';

    if ($id && $titulo && $autor && $ano) {
      $stmt = $pdo->prepare("UPDATE livros SET titulo = :titulo, autor = :autor, ano = :ano WHERE id = :id");
      $stmt->bindParam(':id', $id, PDO::PARAM_INT);
      $stmt->bindParam(':titulo', $titulo);
      $stmt->bindParam(':autor', $autor);
      $stmt->bindParam(':ano', $ano, PDO::PARAM_INT);
      echo $stmt->execute() ? "Livro atualizado com sucesso!" : "Erro ao atualizar livro!";
    } else {
      echo "ID, Título, Autor e Ano são obrigatórios para atualizar!";
    }
  }
  elseif ($action === 'delete') {
    $id = $_GET['id'] ?? '';

    if ($id) {
      $stmt = $pdo->prepare("DELETE FROM livros WHERE id = :id");
      $stmt->bindParam(':id', $id, PDO::PARAM_INT);
      echo $stmt->execute() ? "Livro deletado com sucesso!" : "Erro ao deletar livro!";
    } else {
      echo "ID é obrigatório para deletar!";
    }
  }
  else {
    echo "Ação inválida!";
  }

} catch (PDOException $e) {
  echo "Erro: " . $e->getMessage();
}
?>
